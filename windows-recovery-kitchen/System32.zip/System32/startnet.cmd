wpeinit
pskill -accepteula -nobanner WallpaperHost.exe
